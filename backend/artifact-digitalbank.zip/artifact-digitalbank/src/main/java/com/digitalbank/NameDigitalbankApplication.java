package com.digitalbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NameDigitalbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(NameDigitalbankApplication.class, args);
	}

}
